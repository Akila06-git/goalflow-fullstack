import { useState, useEffect, useRef } from "react";
import React from 'react';

const PURPLE = "#9370DB";
const LAVENDER = "#E6E6FA";
const DARK_PURPLE = "#6A5ACD";
const LIGHT_PURPLE = "#F3EEFF";

const TAMIL_NOTIFS = [
  "😂 Dei... task complete pannalama illa tomorrow nu postpone pannalama?",
  "🔥 Oii Hero! Deadline unaku wait panna maata da!",
  "😎 Innaiku productive ah irundha future self treat kudukum.",
  "☕ Coffee kudichacha? Ippo work start pannu.",
  "😂 Mobile ah 2 hours paatha. Goal ah 2 mins paathiya?",
  "🚀 Semma speed! Continue pannuna mass progress.",
  "🔥 Un goal unna vida serious ah iruku.",
  "😴 Sleep mode off. Beast mode on.",
  "😂 To-do list: Bro, naan inga than iruken.",
  "🏆 Task complete pannita! Feeling like CEO already?",
  "😂 Instagram: 2 Hours. Goal: Seen 2 Minutes Ago.",
  "🔥 Streak maintain pannu da. Break pannatha.",
];

const GOALS = [
  { id: 1, name: "Frontend Developer Job", category: "Career", progress: 75, deadline: "Aug 30", badge: "Interview Ready", icon: "💻", xp: 750 },
  { id: 2, name: "6-Pack Abs Challenge", category: "Fitness", progress: 45, deadline: "Sep 15", badge: "Iron Will", icon: "🏋", xp: 450 },
  { id: 3, name: "Save ₹50,000", category: "Finance", progress: 60, deadline: "Dec 31", badge: "Money Wise", icon: "💰", xp: 600 },
  { id: 4, name: "Read 12 Books", category: "Study", progress: 33, deadline: "Dec 31", badge: "Book Worm", icon: "📚", xp: 330 },
  { id: 5, name: "Learn DSA Completely", category: "Study", progress: 55, deadline: "Oct 10", badge: "Code Ninja", icon: "🧠", xp: 550 },
  { id: 6, name: "Daily Skincare Routine", category: "Self Care", progress: 88, deadline: "Ongoing", badge: "Glow Up", icon: "💄", xp: 880 },
];

const DAILY_TASKS = [
  { id: 1, text: "Complete Project Report", done: false },
  { id: 2, text: "Skincare Routine", done: true },
  { id: 3, text: "Practice English", done: false },
  { id: 4, text: "Exercise 30 mins", done: true },
  { id: 5, text: "Read 20 pages", done: false },
];

const CHAT_GROUPS = [
  { id: 1, name: "Coding Club", icon: "💻", members: 128, online: 24, lastMsg: "Anyone tried the new React 19 features?" },
  { id: 2, name: "Study Buddies", icon: "📚", members: 89, online: 12, lastMsg: "NEET prep session at 8PM today!" },
  { id: 3, name: "Fitness Friends", icon: "🏋", members: 234, online: 45, lastMsg: "Morning run done! 5km streak 🔥" },
  { id: 4, name: "Career Growth", icon: "💼", members: 312, online: 67, lastMsg: "Resume review thread is live!" },
];

const MESSAGES = [
  { id: 1, user: "Priya", text: "Hey everyone! Just finished my DSA revision 🚀", time: "9:12 AM", mine: false },
  { id: 2, user: "You", text: "Amazing! Which topic did you cover today?", time: "9:13 AM", mine: true },
  { id: 3, user: "🤖 Purple Buddy", text: "Hey champion! Your project deadline is approaching. You got this 💪", time: "9:15 AM", mine: false, bot: true },
  { id: 4, user: "Rahul", text: "Just hit a 7-day streak 🔥🔥🔥", time: "9:20 AM", mine: false },
  { id: 5, user: "You", text: "Let's gooo! Keep it up bro 👑", time: "9:21 AM", mine: true },
];

const WEEKLY_DATA = [65, 80, 45, 90, 70, 85, 55];
const DAYS = ["M", "T", "W", "T", "F", "S", "S"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function CircularProgress({ pct, size = 140, strokeW = 12, color = PURPLE }) {
  const r = (size - strokeW) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ * (1 - pct / 100);
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={LAVENDER} strokeWidth={strokeW} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color}
        strokeWidth={strokeW} strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round" style={{ transition: "stroke-dashoffset 1s ease" }} />
    </svg>
  );
}

function MiniBar({ val, max = 100, color = PURPLE }) {
  return (
    <div style={{ background: LAVENDER, borderRadius: 8, height: 8, overflow: "hidden", flex: 1 }}>
      <div style={{ width: `${(val/max)*100}%`, background: color, height: "100%", borderRadius: 8, transition: "width 1s ease" }} />
    </div>
  );
}

function Badge({ text, color = PURPLE }) {
  return (
    <span style={{ background: color + "22", color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20, letterSpacing: 0.3 }}>
      {text}
    </span>
  );
}

function Card({ children, style = {}, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: "#fff", borderRadius: 20, padding: "18px 20px",
      boxShadow: "0 4px 24px rgba(147,112,219,0.10)",
      border: `1px solid ${LAVENDER}`, cursor: onClick ? "pointer" : "default",
      transition: "transform 0.2s, box-shadow 0.2s", ...style
    }}
    onMouseEnter={e => { if(onClick){ e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 8px 32px rgba(147,112,219,0.18)"; }}}
    onMouseLeave={e => { if(onClick){ e.currentTarget.style.transform="translateY(0)"; e.currentTarget.style.boxShadow="0 4px 24px rgba(147,112,219,0.10)"; }}}
    >{children}</div>
  );
}

function NotifToast({ msg, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 4000); return () => clearTimeout(t); }, []);
  return (
    <div style={{
      position: "fixed", top: 20, right: 20, zIndex: 9999,
      background: "linear-gradient(135deg, #9370DB, #6A5ACD)",
      color: "#fff", borderRadius: 16, padding: "14px 20px",
      maxWidth: 320, boxShadow: "0 8px 32px rgba(106,90,205,0.4)",
      fontSize: 13, fontFamily: "'Nunito', sans-serif", fontWeight: 600,
      animation: "slideIn 0.4s ease", display: "flex", alignItems: "flex-start", gap: 10
    }}>
      <span style={{ flex: 1 }}>{msg}</span>
      <span onClick={onClose} style={{ cursor: "pointer", opacity: 0.8, fontSize: 16 }}>×</span>
    </div>
  );
}

function Pet({ mood }) {
  const faces = { happy: "😊", fire: "🔥", sad: "😢", trophy: "🏆" };
  const [animal] = useState("🐼");
  return (
    <div style={{ textAlign: "center", padding: "12px 0" }}>
      <div style={{ fontSize: 52, animation: "bounce 2s infinite", display: "inline-block" }}>{animal}</div>
      <div style={{ fontSize: 22, marginTop: -8 }}>{faces[mood] || "😊"}</div>
      <p style={{ fontSize: 12, color: "#888", margin: "4px 0 0", fontWeight: 600 }}>
        {mood === "fire" ? "You're on fire!" : mood === "sad" ? "Miss me?" : mood === "trophy" ? "Level Up!" : "Great Job!"}
      </p>
    </div>
  );
}

function HomePage({ tasks, setTasks, notif }) {
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
  const emoji = hour < 12 ? "🌸" : hour < 17 ? "☀️" : "🌙";
  const completed = tasks.filter(t => t.done).length;
  const pct = Math.round((completed / tasks.length) * 100);
  const petMood = pct > 70 ? "fire" : pct > 40 ? "happy" : "sad";
  const quotes = [
    "Consistency beats motivation every time.",
    "Your future self is watching you right now.",
    "Small steps every day create massive results.",
    "Dream big, start small, act now.",
  ];
  const [qIdx] = useState(() => Math.floor(Math.random() * quotes.length));
  return (
    <div style={{ padding: "0 0 80px" }}>
      <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "0 0 32px 32px", padding: "28px 20px 36px", color: "#fff", marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
          <div style={{ width: 52, height: 52, borderRadius: "50%", background: "rgba(255,255,255,0.25)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, border: "2px solid rgba(255,255,255,0.5)" }}>👩‍💻</div>
          <div>
            <p style={{ margin: 0, fontSize: 13, opacity: 0.8, fontWeight: 500 }}>{greeting}</p>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, letterSpacing: -0.5 }}>Akila {emoji}</h2>
          </div>
          <div style={{ marginLeft: "auto", position: "relative", cursor: "pointer" }} onClick={notif}>
            <span style={{ fontSize: 24 }}>🔔</span>
            <span style={{ position: "absolute", top: -4, right: -4, background: "#FF6B6B", borderRadius: "50%", width: 14, height: 14, fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700 }}>3</span>
          </div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.15)", borderRadius: 14, padding: "12px 16px", backdropFilter: "blur(10px)" }}>
          <p style={{ margin: 0, fontSize: 13, fontStyle: "italic", opacity: 0.95 }}>✨ "{quotes[qIdx]}"</p>
        </div>
      </div>
      <div style={{ padding: "0 16px" }}>
        <Card style={{ marginBottom: 16, padding: "20px 22px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <div style={{ position: "relative", flexShrink: 0, width: 90, height: 90 }}>
              <CircularProgress pct={pct} size={90} strokeW={10} />
              <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", textAlign: "center", lineHeight: 1.15 }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: PURPLE }}>{pct}%</div>
                <div style={{ fontSize: 9, color: "#aaa", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3 }}>Complete</div>
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ margin: "0 0 7px", fontSize: 16, fontWeight: 800, color: "#222" }}>Activity Progress</p>
              <div style={{ marginBottom: 8 }}>
                {pct > 70
                  ? <span style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "#DCFCE7", color: "#15803D", fontSize: 12, fontWeight: 700, padding: "4px 12px", borderRadius: 20 }}><span style={{ width: 8, height: 8, borderRadius: "50%", background: "#22c55e", display: "inline-block" }} /> Great Job!</span>
                  : pct > 40
                  ? <span style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "#FEF9C3", color: "#A16207", fontSize: 12, fontWeight: 700, padding: "4px 12px", borderRadius: 20 }}><span style={{ width: 8, height: 8, borderRadius: "50%", background: "#EAB308", display: "inline-block" }} /> Keep Going!</span>
                  : <span style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "#FEE2E2", color: "#B91C1C", fontSize: 12, fontWeight: 700, padding: "4px 12px", borderRadius: 20 }}><span style={{ width: 8, height: 8, borderRadius: "50%", background: "#EF4444", display: "inline-block" }} /> Let's Focus!</span>
                }
              </div>
              <p style={{ margin: "0 0 8px", fontSize: 13, color: "#555", fontWeight: 600 }}>{completed} of {tasks.length} tasks done today</p>
              <div style={{ background: LAVENDER, borderRadius: 10, height: 8, overflow: "hidden" }}>
                <div style={{ width: `${pct}%`, height: "100%", background: `linear-gradient(90deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: 10, transition: "width 1s ease" }} />
              </div>
            </div>
          </div>
        </Card>
        <Card style={{ marginBottom: 16 }}>
          <p style={{ margin: "0 0 4px", fontSize: 12, color: "#888", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>Productivity Pet</p>
          <Pet mood={petMood} />
        </Card>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 16 }}>
          {[{ label: "Tasks Done", val: completed, icon: "✅" }, { label: "Streak Days", val: 7, icon: "🔥" }, { label: "Focus Hrs", val: 3.5, icon: "⏱️" }].map(s => (
            <Card key={s.label} style={{ padding: "14px 10px", textAlign: "center" }}>
              <div style={{ fontSize: 22 }}>{s.icon}</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: PURPLE }}>{s.val}</div>
              <div style={{ fontSize: 10, color: "#888", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.3 }}>{s.label}</div>
            </Card>
          ))}
        </div>
        <Card style={{ marginBottom: 16 }}>
          <p style={{ margin: "0 0 14px", fontWeight: 800, fontSize: 14, color: "#333" }}>📅 Last 7 Days</p>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            {DAYS.map((d, i) => {
              const statuses = ["done","done","pending","done","done","perfect","pending"];
              const s = statuses[i];
              return (
                <div key={i} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 18, marginBottom: 4 }}>{s === "done" ? "✅" : s === "perfect" ? "🔥" : "⚪"}</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#888" }}>{d}</div>
                </div>
              );
            })}
          </div>
        </Card>
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <p style={{ margin: 0, fontWeight: 800, fontSize: 14, color: "#333" }}>🎯 Today's Goals</p>
            <Badge text={`${completed}/${tasks.length}`} />
          </div>
          {tasks.map(t => (
            <div key={t.id} onClick={() => setTasks(ts => ts.map(x => x.id === t.id ? { ...x, done: !x.done } : x))}
              style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid " + LAVENDER, cursor: "pointer", textDecoration: t.done ? "line-through" : "none", opacity: t.done ? 0.6 : 1, transition: "opacity 0.3s" }}>
              <span style={{ fontSize: 18 }}>{t.done ? "✅" : "☐"}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#444" }}>{t.text}</span>
            </div>
          ))}
        </Card>
        <Card>
          <p style={{ margin: "0 0 14px", fontWeight: 800, fontSize: 14, color: "#333" }}>📊 Weekly Productivity</p>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 80 }}>
            {WEEKLY_DATA.map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div style={{ width: "100%", height: `${v}%`, background: `linear-gradient(180deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "6px 6px 0 0", transition: "height 1s ease" }} />
                <span style={{ fontSize: 10, color: "#888", fontWeight: 700 }}>{DAYS[i]}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function GoalsPage({ notif }) {
  const [celebrate, setCelebrate] = useState(false);
  const [filter, setFilter] = useState("All");
  const categories = ["All", "Career", "Fitness", "Finance", "Study", "Self Care"];
  const filtered = filter === "All" ? GOALS : GOALS.filter(g => g.category === filter);
  function complete(g) {
    setCelebrate(true);
    notif(`🏆 "${g.name}" marked complete! +${g.xp} XP gained!`);
    setTimeout(() => setCelebrate(false), 2000);
  }
  return (
    <div style={{ padding: "0 0 80px" }}>
      {celebrate && (
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, zIndex: 8888, background: "rgba(147,112,219,0.15)", pointerEvents: "none", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 80 }}>🎉🎊🏆🎊🎉</div>
      )}
      <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "0 0 32px 32px", padding: "28px 20px 36px", color: "#fff", marginBottom: 20 }}>
        <h2 style={{ margin: "0 0 4px", fontSize: 24, fontWeight: 800 }}>🎯 My Goals</h2>
        <p style={{ margin: 0, opacity: 0.8, fontSize: 13 }}>Track. Achieve. Celebrate.</p>
        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          {[{ v: "Level 4", l: "Current" }, { v: "2,760", l: "Total XP" }, { v: "6/8", l: "Active" }].map(s => (
            <div key={s.l} style={{ background: "rgba(255,255,255,0.18)", borderRadius: 12, padding: "10px 16px", flex: 1, textAlign: "center" }}>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{s.v}</div>
              <div style={{ fontSize: 11, opacity: 0.8 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: "0 16px" }}>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, marginBottom: 16, scrollbarWidth: "none" }}>
          {categories.map(c => (
            <button key={c} onClick={() => setFilter(c)} style={{ padding: "7px 16px", borderRadius: 20, border: "none", cursor: "pointer", background: filter === c ? PURPLE : LAVENDER, color: filter === c ? "#fff" : PURPLE, fontWeight: 700, fontSize: 12, whiteSpace: "nowrap", transition: "all 0.2s" }}>{c}</button>
          ))}
        </div>
        <Card style={{ marginBottom: 16, background: `linear-gradient(135deg, #FFF8E1, #FFF3CD)` }}>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>🔥 Daily Challenges</p>
          {["Drink 2L Water", "Complete 3 Tasks", "Study 1 Hour"].map((c, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: i < 2 ? "1px solid rgba(0,0,0,0.06)" : "none" }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>🔥 {c}</span>
              <span style={{ background: "#FF8C00", color: "#fff", borderRadius: 10, padding: "3px 10px", fontSize: 11, fontWeight: 700 }}>+50 pts</span>
            </div>
          ))}
        </Card>
        {filtered.map(g => (
          <Card key={g.id} style={{ marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <span style={{ fontSize: 28 }}>{g.icon}</span>
                <div>
                  <p style={{ margin: 0, fontWeight: 800, fontSize: 15, color: "#222" }}>{g.name}</p>
                  <Badge text={g.category} color={DARK_PURPLE} />
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontWeight: 800, fontSize: 20, color: PURPLE }}>{g.progress}%</div>
                <div style={{ fontSize: 10, color: "#888" }}>🗓 {g.deadline}</div>
              </div>
            </div>
            <MiniBar val={g.progress} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
              <Badge text={`🏆 ${g.badge}`} color={PURPLE} />
              <button onClick={() => complete(g)} style={{ background: PURPLE, color: "#fff", border: "none", borderRadius: 10, padding: "5px 14px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>Mark Done ✓</button>
            </div>
          </Card>
        ))}
        <Card>
          <p style={{ margin: "0 0 14px", fontWeight: 800, fontSize: 14 }}>🏅 Achievements</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
            {[{ icon: "🥉", label: "Bronze Achiever", earned: true }, { icon: "🥈", label: "Silver Achiever", earned: true }, { icon: "🥇", label: "Gold Achiever", earned: false }, { icon: "👑", label: "Productivity King", earned: false }, { icon: "🔥", label: "7-Day Streak", earned: true }, { icon: "🚀", label: "Goal Crusher", earned: true }].map(b => (
              <div key={b.label} style={{ textAlign: "center", padding: "10px 4px", borderRadius: 14, background: b.earned ? LIGHT_PURPLE : "#f5f5f5", opacity: b.earned ? 1 : 0.45 }}>
                <div style={{ fontSize: 28 }}>{b.icon}</div>
                <div style={{ fontSize: 9, fontWeight: 700, color: b.earned ? PURPLE : "#999", marginTop: 4 }}>{b.label}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function ChatPage({ notif }) {
  const [activeGroup, setActiveGroup] = useState(null);
  const [messages, setMessages] = useState(MESSAGES);
  const [input, setInput] = useState("");
  const bottomRef = useRef();
  useEffect(() => { if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" }); }, [messages]);
  function sendMsg() {
    if (!input.trim()) return;
    setMessages(m => [...m, { id: Date.now(), user: "You", text: input, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), mine: true }]);
    setInput("");
    setTimeout(() => {
      setMessages(m => [...m, { id: Date.now() + 1, user: "🤖 Purple Buddy", text: "Great engagement! Your streak is growing 🌟", time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), mine: false, bot: true }]);
    }, 1500);
  }
  if (activeGroup) {
    return (
      <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#F8F5FF" }}>
        <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, padding: "16px 20px", display: "flex", alignItems: "center", gap: 12, color: "#fff" }}>
          <button onClick={() => setActiveGroup(null)} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 10, padding: "6px 10px", cursor: "pointer", fontWeight: 700 }}>←</button>
          <span style={{ fontSize: 24 }}>{activeGroup.icon}</span>
          <div>
            <p style={{ margin: 0, fontWeight: 800, fontSize: 16 }}>{activeGroup.name}</p>
            <p style={{ margin: 0, fontSize: 11, opacity: 0.8 }}>🟢 {activeGroup.online} online</p>
          </div>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "16px", display: "flex", flexDirection: "column", gap: 10 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{ display: "flex", justifyContent: msg.mine ? "flex-end" : "flex-start" }}>
              <div style={{ maxWidth: "75%" }}>
                {!msg.mine && <p style={{ margin: "0 0 3px 8px", fontSize: 11, color: msg.bot ? PURPLE : "#888", fontWeight: 700 }}>{msg.user}</p>}
                <div style={{ padding: "10px 14px", borderRadius: msg.mine ? "18px 18px 4px 18px" : "18px 18px 18px 4px", background: msg.mine ? `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})` : msg.bot ? `linear-gradient(135deg, #E6E6FA, #D8C8F0)` : "#fff", color: msg.mine ? "#fff" : "#333", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", fontSize: 13, fontWeight: 500 }}>{msg.text}</div>
                <p style={{ margin: "3px 8px 0", fontSize: 10, color: "#aaa", textAlign: msg.mine ? "right" : "left" }}>{msg.time}</p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
        <div style={{ padding: "12px 16px", background: "#fff", borderTop: `1px solid ${LAVENDER}`, display: "flex", gap: 10, alignItems: "center" }}>
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMsg()} placeholder="Type a message..." style={{ flex: 1, border: `1.5px solid ${LAVENDER}`, borderRadius: 24, padding: "10px 16px", fontSize: 13, outline: "none", fontFamily: "inherit" }} />
          <button onClick={sendMsg} style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, border: "none", borderRadius: 24, padding: "10px 18px", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>→</button>
        </div>
      </div>
    );
  }
  return (
    <div style={{ padding: "0 0 80px" }}>
      <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "0 0 32px 32px", padding: "28px 20px 36px", color: "#fff", marginBottom: 20 }}>
        <h2 style={{ margin: "0 0 4px", fontSize: 24, fontWeight: 800 }}>💬 Community</h2>
        <p style={{ margin: 0, opacity: 0.8, fontSize: 13 }}>Grow together. Stay accountable.</p>
      </div>
      <div style={{ padding: "0 16px" }}>
        <Card style={{ marginBottom: 16, background: LIGHT_PURPLE, border: `1.5px solid ${LAVENDER}` }}>
          <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <span style={{ fontSize: 28 }}>🤖</span>
            <div>
              <p style={{ margin: "0 0 4px", fontWeight: 800, fontSize: 13, color: PURPLE }}>Purple Buddy</p>
              <p style={{ margin: 0, fontSize: 13, color: "#555" }}>Hey Akila! You completed 80% of today's goals. Amazing work! 🌟</p>
            </div>
          </div>
        </Card>
        <p style={{ fontWeight: 800, fontSize: 16, color: "#222", margin: "0 0 12px" }}>Your Groups</p>
        {CHAT_GROUPS.map(g => (
          <Card key={g.id} style={{ marginBottom: 12 }} onClick={() => setActiveGroup(g)}>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <div style={{ width: 46, height: 46, borderRadius: 14, background: LIGHT_PURPLE, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>{g.icon}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <p style={{ margin: 0, fontWeight: 800, fontSize: 14 }}>{g.name}</p>
                  <span style={{ fontSize: 10, color: "#22c55e", fontWeight: 700 }}>🟢 {g.online}</span>
                </div>
                <p style={{ margin: "2px 0 0", fontSize: 12, color: "#888", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{g.lastMsg}</p>
              </div>
            </div>
          </Card>
        ))}
        <Card style={{ marginTop: 4 }}>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>😂 Community Vibes</p>
          {TAMIL_NOTIFS.slice(0, 4).map((n, i) => (
            <div key={i} style={{ fontSize: 12, color: "#555", padding: "7px 0", borderBottom: i < 3 ? `1px solid ${LAVENDER}` : "none", fontWeight: 500 }}>{n}</div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function ProfilePage({ notif }) {
  const [darkMode, setDarkMode] = useState(false);
  const [avatar, setAvatar] = useState("👩‍💻");
  const avatars = ["👩‍💻", "👩", "🏋", "🎨", "👨‍💻", "👨", "🎮", "🧑"];
  const stats = [
    { label: "Tasks Done", val: 142, icon: "✅" }, { label: "Goals Met", val: 18, icon: "🎯" },
    { label: "Prod Score", val: "87%", icon: "📊" }, { label: "Hours Focused", val: 124, icon: "⏱️" },
    { label: "Streak", val: "7 days", icon: "🔥" }, { label: "Best Streak", val: "14 days", icon: "💪" },
  ];
  return (
    <div style={{ padding: "0 0 80px" }}>
      <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "0 0 32px 32px", padding: "36px 20px 48px", color: "#fff", textAlign: "center", marginBottom: 20 }}>
        <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.25)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, margin: "0 auto 12px", border: "3px solid rgba(255,255,255,0.5)" }}>{avatar}</div>
        <h2 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 800 }}>Akila Sharma</h2>
        <p style={{ margin: "0 0 10px", opacity: 0.8, fontSize: 13 }}>Level 4 · Productivity Hero</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, flexWrap: "wrap" }}>
          <Badge text="🔥 7-Day Streak" color="#FF8C00" />
          <Badge text="⭐ Top 30%" color={PURPLE} />
        </div>
      </div>
      <div style={{ padding: "0 16px" }}>
        <Card style={{ marginBottom: 16 }}>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>🎭 Choose Avatar</p>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {avatars.map(a => (
              <div key={a} onClick={() => setAvatar(a)} style={{ width: 44, height: 44, borderRadius: 14, background: avatar === a ? PURPLE : LIGHT_PURPLE, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, cursor: "pointer", transition: "all 0.2s", border: avatar === a ? `2px solid ${DARK_PURPLE}` : "2px solid transparent" }}>{a}</div>
            ))}
          </div>
        </Card>
        <Card style={{ marginBottom: 16 }}>
          <p style={{ margin: "0 0 14px", fontWeight: 800, fontSize: 14 }}>📊 Statistics</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
            {stats.map(s => (
              <div key={s.label} style={{ textAlign: "center", padding: "10px 4px", background: LIGHT_PURPLE, borderRadius: 14 }}>
                <div style={{ fontSize: 20 }}>{s.icon}</div>
                <div style={{ fontWeight: 800, fontSize: 16, color: PURPLE }}>{s.val}</div>
                <div style={{ fontSize: 9, color: "#888", fontWeight: 700 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card style={{ marginBottom: 16, background: LIGHT_PURPLE }}>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>🌸 Purple Buddy's Insights</p>
          {["You're most productive on Mondays! Plan big tasks then.", "Your study streak improved by 40% this month. 🚀", "Fitness goals need more attention — try 5-min micro-workouts."].map((tip, i) => (
            <div key={i} style={{ display: "flex", gap: 10, padding: "8px 0", borderBottom: i < 2 ? `1px solid ${LAVENDER}` : "none" }}>
              <span style={{ fontSize: 14 }}>✨</span>
              <span style={{ fontSize: 12, color: "#555", fontWeight: 500 }}>{tip}</span>
            </div>
          ))}
        </Card>
        <Card>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>⚙️ Settings</p>
          {[
            { label: "Dark Mode", icon: "🌙", toggle: true, val: darkMode, set: setDarkMode },
            { label: "Notifications", icon: "🔔", toggle: true, val: true, set: () => {} },
            { label: "Tamil Notifications", icon: "😂", toggle: true, val: true, set: () => {} },
            { label: "Language", icon: "🌐", sub: "Tamil / English", toggle: false },
            { label: "Privacy", icon: "🔒", sub: "Friends Only", toggle: false },
          ].map((s, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: i < 4 ? `1px solid ${LAVENDER}` : "none" }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <span style={{ fontSize: 18 }}>{s.icon}</span>
                <div>
                  <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>{s.label}</p>
                  {s.sub && <p style={{ margin: 0, fontSize: 11, color: "#888" }}>{s.sub}</p>}
                </div>
              </div>
              {s.toggle && (
                <div onClick={() => s.set && s.set(!s.val)} style={{ width: 44, height: 24, borderRadius: 12, background: s.val ? PURPLE : "#ddd", cursor: "pointer", position: "relative", transition: "background 0.3s" }}>
                  <div style={{ position: "absolute", top: 2, left: s.val ? 22 : 2, width: 20, height: 20, borderRadius: "50%", background: "#fff", transition: "left 0.3s", boxShadow: "0 1px 4px rgba(0,0,0,0.2)" }} />
                </div>
              )}
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function CalendarPage() {
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [selectedDay, setSelectedDay] = useState(today.getDate());
  const taskDays = { 3: "complete", 7: "pending", 12: "complete", 15: "complete", 18: "pending", 22: "complete", 25: "pending" };
  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  return (
    <div style={{ padding: "0 0 80px" }}>
      <div style={{ background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, borderRadius: "0 0 32px 32px", padding: "28px 20px 36px", color: "#fff", marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <button onClick={() => { if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(y => y - 1); } else setCurrentMonth(m => m - 1); }} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 10, padding: "8px 14px", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>‹</button>
          <div style={{ textAlign: "center" }}>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>{MONTHS[currentMonth]}</h2>
            <p style={{ margin: 0, fontSize: 13, opacity: 0.8 }}>{currentYear}</p>
          </div>
          <button onClick={() => { if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(y => y + 1); } else setCurrentMonth(m => m + 1); }} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 10, padding: "8px 14px", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>›</button>
        </div>
      </div>
      <div style={{ padding: "0 16px" }}>
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", marginBottom: 8 }}>
            {["Su","Mo","Tu","We","Th","Fr","Sa"].map(d => (
              <div key={d} style={{ textAlign: "center", fontSize: 11, fontWeight: 800, color: "#888", padding: "4px 0" }}>{d}</div>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
            {cells.map((d, i) => {
              const isToday = d === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
              const isSelected = d === selectedDay;
              const taskStatus = taskDays[d];
              return (
                <div key={i} onClick={() => d && setSelectedDay(d)} style={{ aspectRatio: "1", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 12, cursor: d ? "pointer" : "default", background: isSelected ? PURPLE : isToday ? LIGHT_PURPLE : "transparent", border: isToday && !isSelected ? `1.5px solid ${PURPLE}` : "1.5px solid transparent", transition: "all 0.2s" }}>
                  {d && (
                    <>
                      <span style={{ fontSize: 13, fontWeight: isToday || isSelected ? 800 : 500, color: isSelected ? "#fff" : isToday ? PURPLE : "#333" }}>{d}</span>
                      {taskStatus && <div style={{ width: 6, height: 6, borderRadius: "50%", background: taskStatus === "complete" ? "#22c55e" : "#f59e0b", marginTop: 2 }} />}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
        <Card>
          <p style={{ margin: "0 0 12px", fontWeight: 800, fontSize: 14 }}>📋 {MONTHS[currentMonth]} {selectedDay} — Tasks</p>
          {[{ text: "Morning Run", time: "6:00 AM", color: "#22c55e" }, { text: "Team Meeting", time: "10:00 AM", color: PURPLE }, { text: "DSA Practice", time: "2:00 PM", color: "#f59e0b" }, { text: "Evening Study", time: "7:00 PM", color: DARK_PURPLE }].map((t, i) => (
            <div key={i} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: i < 3 ? `1px solid ${LAVENDER}` : "none" }}>
              <div style={{ width: 4, height: 36, borderRadius: 2, background: t.color, flexShrink: 0 }} />
              <div>
                <p style={{ margin: 0, fontWeight: 700, fontSize: 13 }}>{t.text}</p>
                <p style={{ margin: 0, fontSize: 11, color: "#888" }}>⏰ {t.time}</p>
              </div>
            </div>
          ))}
          <button style={{ width: "100%", marginTop: 12, padding: "10px", background: `linear-gradient(135deg, ${PURPLE}, ${DARK_PURPLE})`, color: "#fff", border: "none", borderRadius: 14, fontWeight: 800, fontSize: 13, cursor: "pointer" }}>+ Add Task</button>
        </Card>
      </div>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState("home");
  const [tasks, setTasks] = useState(DAILY_TASKS);
  const [notifMsg, setNotifMsg] = useState(null);
  const [notifKey, setNotifKey] = useState(0);
  function showNotif(msg) {
    if (!msg) { const r = TAMIL_NOTIFS[Math.floor(Math.random() * TAMIL_NOTIFS.length)]; setNotifMsg(r); }
    else { setNotifMsg(msg); }
    setNotifKey(k => k + 1);
  }
  useEffect(() => {
    const t = setTimeout(() => showNotif("🌸 Good Morning! Ready to conquer your goals today?"), 1200);
    return () => clearTimeout(t);
  }, []);
  const navItems = [
    { id: "home", icon: "🏠", label: "Home" },
    { id: "goals", icon: "🎯", label: "Goals" },
    { id: "calendar", icon: "📅", label: "Calendar" },
    { id: "chat", icon: "💬", label: "Chat" },
    { id: "profile", icon: "👤", label: "Profile" },
  ];
  return (
    <div style={{ maxWidth: 430, margin: "0 auto", background: "#F8F5FF", minHeight: "100vh", position: "relative", fontFamily: "'Nunito', 'Poppins', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');
        @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes slideIn { from{transform:translateX(100px);opacity:0} to{transform:translateX(0);opacity:1} }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #F8F5FF; }
        ::-webkit-scrollbar { width: 0; }
      `}</style>
      {notifMsg && <NotifToast key={notifKey} msg={notifMsg} onClose={() => setNotifMsg(null)} />}
      <div style={{ paddingBottom: 70 }}>
        {page === "home" && <HomePage tasks={tasks} setTasks={setTasks} notif={showNotif} />}
        {page === "goals" && <GoalsPage notif={showNotif} />}
        {page === "calendar" && <CalendarPage />}
        {page === "chat" && <ChatPage notif={showNotif} />}
        {page === "profile" && <ProfilePage notif={showNotif} />}
      </div>
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: "rgba(255,255,255,0.96)", backdropFilter: "blur(20px)", borderTop: `1px solid ${LAVENDER}`, display: "flex", justifyContent: "space-around", padding: "8px 0 12px", zIndex: 1000, boxShadow: "0 -4px 24px rgba(147,112,219,0.12)" }}>
        {navItems.map(n => (
          <div key={n.id} onClick={() => setPage(n.id)} style={{ textAlign: "center", cursor: "pointer", padding: "4px 12px", transition: "all 0.2s" }}>
            <div style={{ fontSize: 22, filter: page === n.id ? "none" : "grayscale(0.6) opacity(0.6)", transform: page === n.id ? "translateY(-2px) scale(1.15)" : "none", transition: "all 0.2s" }}>{n.icon}</div>
            <div style={{ fontSize: 9, fontWeight: 800, color: page === n.id ? PURPLE : "#aaa", marginTop: 2, textTransform: "uppercase", letterSpacing: 0.3 }}>{n.label}</div>
            {page === n.id && <div style={{ width: 4, height: 4, borderRadius: "50%", background: PURPLE, margin: "2px auto 0" }} />}
          </div>
        ))}
      </div>
    </div>
  );
}
